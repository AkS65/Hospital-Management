<?php
  include_once('conection.php'); 
  ?>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style type="text/css">
  .ii {
    padding: 200px 500px;
    
    background-color: lavenderblush;
    padding-bottom: 70px;

}

.yy {
    background-color: #dcb0c5;
    box-shadow: 8px 5px #c148c1;
}
.yy h2 {
    padding-top: 15px;
}
.yy p {
    padding-bottom: 15px;
}



</style>
<body>
  <?php
    include_once('topbar.php')
  ?>
  <
<div class="ii">
  <div class="yy">
<div class="container mt-3">
  <h2 align="center">LOGIN</h2>
  <form action="/action_page.php">
    <div class="mb-3 mt-3">
      <label for="email">OP NUMBER</label>
      <input type="number" class="form-control" id="num"  name="number">
    </div>
    <div class="mb-3">
      <label for="pwd">NAME</label>
      <input type="taxt" class="form-control" id="text"  name="name">
    </div>
    <p align="center">New Patient <a href="register.php">Register Here</a></p> 
    
    <p align="center"><a href="" class="btn btn-primary">LOGIN</a></p>
  </form>
</div>
</div>
</div>


<?php
  include_once('fooder.php')
?>

</body>
</html>
