<?php 
    error_reporting(0);
    
    include_once('../admin/conection.php');
    if(isset($_POST['add'])){
         $name=$_POST['text'];
        $email=$_POST['email'];
        $phone=$_POST['number'];
        $gender=$_POST['gender'];
        $hospital=$_POST['name'];
        $location=$_POST['location'];
        $op=rand();
        $sql="INSERT INTO patient (name,email,phone,gender,hospital,location,opnumber) VALUES ('$name','$email','$phone','$gender','$hospital','$location','$op')";
         if(mysqli_query($conn,$sql)){
            $message="patient Added Succesfully";
        }
        else{
            $error="Error";
        }


    }

    
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Medilab Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab - v4.7.1
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<style type="text/css">
    .card {
    padding: 100px 300px;

    
}
.card {
    background-color: blanchedalmond;
}
.new {
    background-color: #db88bc;
    box-shadow: 8px 5px #c148c1;
}
.new h4 {
    padding-top: 15px;
}
.new p {
    margin-top: 41px;
}
.new span {
    color: red;
}
</style>

<body>
    <?php
    include_once('topbar.php')
    ?>
    
        


                <section id="main-content">
                    <div class="row">
                        <?php
                            if($message!=""){
                            ?>
                            <div class="bg-success col-lg-12">
                                <?php echo $message;?>
                            </div>
                            <?php
                            }
                            else if($error!=""){
                            ?>
                                <div class="bg-danger col-lg-12">
                                    <?php  echo $error;
                                    ?>
                                </div>
                            <?php
                            }
                        ?>
                        
                        
                        <div class="col-lg-12">
                            <div class="next">
                            <div class="card">
                              
                                    <div class="new">

                                <div class="card-title">
                                    <h4 align="center">ADD PATIENT</h4>
                                    
                                </div>
                                    <div class="card-body">
                                    <div class="basic-form">
                                        <form method="post">
                                            <div class="form-group">
                                                <label> Name</label><span>*</span>  
                                                <input type="text" class="form-control" required name="text">
                                            </div>
                                            <div class="form-group">
                                                <label> Email</label>
                                                <input type="email" class="form-control" required name="email"><span>(optional)</span>

                                            </div>
                                            <div class="form-group">
                                                <label>phone no</label><span>*</span>
                                                <input type="number" class="form-control" required name="number">

                                            </div>
                                            <div class="form-group">
                                                <label>gender</label><span>*</span><br>
                                                <input type="radio" value="male" required name="gender" >male
                                                <input type="radio"   value="female" required name="gender" >female

                                            </div>
                                            <div class="form-group">
                                                <label>Hospital</label>
                                                <select class="form-control hospiatlname" required name="name" >
                                                    <?php
                                                    $sql="SELECT * FROM hospital";
                                                    $result=mysqli_query($conn, $sql);
                                                    $hospitalarray=[];
                                                     if(mysqli_num_rows($result)>0){
                                                        while($row=mysqli_fetch_assoc($result)){ 
                                                            //print_r($row);  
                                                            $hospitalarray[]=$row['hospitalname'];
                                                       }
                                                    } 
                                                    //print_r($hospitalarray);
                                                    $unique=array_unique($hospitalarray);
                                                    //print_r($unique);
                                                    for($i=0;$i<count($hospitalarray);$i++){
                                                        if($unique[$i]!=""){
                                                        ?>
                                                        <option><?php echo $unique[$i];?></option>
                                                        <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label>Hospital Location</label>
                                                <select type="text" class="form-control" required name="location" id="location" disabled></select>
                                            </div>


                                            <p align="center"><button type="submit" class="btn btn-primary" name="add">ADD</button></p>
                                        </form>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
            
            </div>
                        </section>
                        <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <?php
  include_once('fooder.php')
  ?>

</body>

</html>
<script type="text/javascript">
        $(document).ready(function() {
            $('.hospiatlname').select2();
        });



        $(".hospiatlname ").change(function() {
            a = $('.hospiatlname ').val();    
            //alert(a);            
            $.ajax({
               type: "POST",
               url: "answer.php",
               data: {"hospiatlname":a},
               success: function(html){
                //alert(html);
                 /* $("#questionajax").html(html).show();*/
                 $( "#location" ).prop( "disabled", false );
                 //$("#location").adda;
                 $("#location").html(html);
               }
            });
            
        });
