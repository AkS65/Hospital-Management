<div class="row">
                        <div class="col-lg-12">
                            <div class="footer">
                                <p><?php echo date("Y");?>© AJINHOSPITAL.</p>
                            </div>
                        </div>
                    </div>