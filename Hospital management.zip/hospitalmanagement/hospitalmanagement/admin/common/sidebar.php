<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                    <div class="logo"><a href="index.html">
                            <!-- <img src="images/logo.png" alt="" /> --><span>AJIN HOSPITALS</span></a></div>
                    <li class="label">Main</li>
                    <li><a class=""> Dashboard</a>
                        
                    </li>

                    
                    
                    <li><a class="sidebar-sub-toggle"><i class="ti-home"></i> Hospitals <span
                                class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="addhospital_dashboard.php">Add Hospital</a></li>
                            <li><a href="viewhospital.php">View Hospital</a></li>
                            
                        </ul>
                    </li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-layout-grid4-alt"></i> Doctors<span
                                class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="adddoctors.php">Add Doctors</a></li>

                            <li><a href="viewdoctor.php">view Doctors</a></li>

                        </ul>

                    </li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-layout-grid4-alt"></i> Patients<span
                                class="sidebar-collapse-icon ti-angle-down"></span></a>
                                <ul>
                            <li><a href="addpatient.php">Add  Patients</a></li>

                            <li><a href="viewpatient.php">view  Patients</a></li>

                        </ul>
                     
                        
                    </li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-layout-grid4-alt"></i> Appointment<span
                                class="sidebar-collapse-icon ti-angle-down"></span></a>
                                <ul>
                            <li><a href="addappoitment.php">Add  Appointment</a></li>

                            <li><a href="viewappoitment.php">view  Appointment</a></li>

                        </ul>
                     
                        
                    </li>
                    
            </div>
        </div>
    </div>