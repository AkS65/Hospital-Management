<?php
	error_reporting(0);
    
    include_once('conection.php');
    $hospitalname=$_POST['hospiatlname'];
	$se="SELECT * FROM hospital WHERE hospitalname='$hospitalname'";
	$re=mysqli_query($conn,$se);
	while($r=mysqli_fetch_assoc($re)){
		?>
		<option value="<?php echo $r['hospitallocation'];?>	"><?php echo $r['hospitallocation'];?></option>
		<?php
	}