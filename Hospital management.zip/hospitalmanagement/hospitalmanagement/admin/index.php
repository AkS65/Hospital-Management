 <?php 
	include_once('conection.php');
	if(isset($_POST['sub'])){
		$email=$_POST['email'];
		$password=$_POST['password'];

		$sql="SELECT * FROM admin WHERE email='$email' AND password='$password'";
		$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				header("Location:dashboard.php");
				
				?>
				<script type="text/javascript">
					alert("Success"); 
				</script>
				<?php
			}
			else{
				?>
				<script type="text/javascript">
					alert("wrough details");

				</script>
				<?php
			}
		}
			
?>

 
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Page</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"><link rel="stylesheet" href="./style.css">

</head>
<body>
<div id="loader">
	<div class="container">
	<div class="circle"></div>
		<div class="circle"></div>
		<div class="circle"></div>
		<div class="shadow"></div>
		<div class="shadow"></div>
		<div class="shadow"></div>
	</div>
</div> 
<style>
		 
	#loader{ 
padding: 0;
margin: 0;
width: 100%;
height: 100vh;
background: red;
}

.container{
	width: 200px;
	height: 60px;
	position: absolute;
	left: 50%;
	top: 50%;
	transform: translate(-50%,-50%);
}

.circle{
	width: 20px;
	height: 20px;
	position: absolute;
	border-radius: 50%;
	background-color: white;
	left: 15%;
	transform-origin: 50%;
	animation: circle.6s alternate infinite ease;

	}

	@keyframes circle{
		0%{
			top: 60px;
			height: 5px;
			border-radius: 50px 50px 25px 25px;
			transform: scaleX(1.7);

		}
		40%{
			height: 20px;
			border-radius: 50%;
			transform: scaleX(1);
		}
		100%{
			top: 0%;
			transform: scaleX(1.7);
		}
	}

	.circle:nth-child(2){
		left: 45%;
		animation-delay: -2s;
	}
	.circle:nth-child(3){
		left: auto;
		right: 15%;
		animation-delay: -3s;
	}
	.shadow{
		width: 20px;
		height: 4px;
		border-radius: 50%;
		background-color: rgba(220, 91, 81, .5);
		position: absolute;
		top: 62px;
		transform-origin: 50%;
		z-index: -1;
		left: 15%;
		filter: blur(1px);
		animation: shadow .5s alternate infinite ease;
	}

	@keyframes shadow{
		0%{
			transform: scaleX(1.5);

		}
		40%{
			transform: scaleX(1);
			opacity: .7;
		}
		100%{
			transform: scaleX(.2);
			opacity: .4;
		}
	}

	.shadow:nth-child(1){
		left: 45%;
		animation-delay: .2s;
	}
	.shadow:nth-child(2){
		left: auto;
		right: 15%;
		animation-delay: .3s;
	}
</style> 
<!-- partial:index.partial.html -->
<div class="box-form">
	<div class="left" style="width: 60%; float: left;">
		<div class="overlay">
		<h1 align="center">AJIN <br>HOSPITALS.</h1>
		
		</div>
	</div>
	
	<form method="post" style="width:40%;float: left;">
		<div class="right">

		<div class="inputs">
			<input type="text" placeholder="email" name="email">
			<br>
			<input type="password" placeholder="password" name="password">
		</div>
			
			<br><br>
			
		
			
			<br>
			<button class="submit" name="sub">Login</button>
	</div>
	
</div>
</form>
<script src="http://code.jquery.com/jquery-1.8.2.js"></script> 
<!-- partial -->
  <script type="text/javascript">  
   $(window).load(function() {  
      $("#loader").fadeOut();  
   });
</script> 
</body>
</html>
