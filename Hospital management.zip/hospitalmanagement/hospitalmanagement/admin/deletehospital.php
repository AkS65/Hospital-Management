<?php 
	include_once('conection.php');
?>
<?php 
  $id=$_GET['id'];

	$del="DELETE FROM hospital WHERE id=$id";
	$result=mysqli_query($conn, $del);
	header('Location:viewhospital.php');
		?> 