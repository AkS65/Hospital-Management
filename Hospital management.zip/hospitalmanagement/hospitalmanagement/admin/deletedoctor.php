<?php 
	include_once('conection.php');
?>
<?php 
  $id=$_GET['id'];

	$del="DELETE FROM doctor WHERE id=$id";
	$result=mysqli_query($conn, $del);
	header('Location:viewdoctor.php');
		?> 