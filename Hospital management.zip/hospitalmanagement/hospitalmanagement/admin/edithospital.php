<?php
	include_once('conection.php'); 
	?>
<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Focus Admin: Creative Admin Dashboard</title>
    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
    <!-- Styles -->
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/chartist/chartist.min.css" rel="stylesheet">
    <link href="css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="css/lib/themify-icons.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/lib/weather-icons.css" rel="stylesheet" />
    <link href="css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
	<title></title>
</head>
<body>
    <?php
     include_once('common/sidebar.php');
?>
    <!-- /# sidebar -->

    <?php 
    include_once('common/topbar.php');
    ?>


    <?php 
            $id=$_GET['id'];
            $selectsql="SELECT * FROM hospital WHERE id=$id";
            $selectsqlresult = mysqli_query($conn, $selectsql);

            if (mysqli_num_rows($selectsqlresult) > 0) {
              // output data of each row
              while($rowselect = mysqli_fetch_assoc($selectsqlresult)) {
                //print_r($rowselect);
              
            ?>
	
		
	<div class="row">

                        <div class="col-lg-6" style="margin-left: 450px;">
                            <div class="card">
                                <div class="card-title">
                                    <h4>EDIT</h4>
                                    
                                </div>
                                <form method="post">
				 				
                                <div class="card-body">
                                    <div class="basic-form" >
                                        <form method="post">
                                            <div class="form-group">
                                                <label>hospitalname</label> 
                                                <input type="text" class="form-control" name="name" value="<?php echo $rowselect['hospitalname'];?>">
                                            </div>
                                            <div class="form-group">
                                                <label>hospitallocation</label>
                                                <input type="text" class="form-control" name="location" value="<?php echo $rowselect['hospitallocation'];?>">
                                            </div>                                            
                                            <div class="form-group">
                                                <label>hospitalemail</label>
                                                <input type="text" class="form-control" name="email" value="<?php echo $rowselect['hospitalemail'];?>">
                                            </div><div class="form-group">
                                                <label>hospitalpassword</label>
                                                <input type="password" class="form-control" name="password" value="<?php echo $rowselect['hospitalpassword'];?>">
                                            </div>
                                            
                                            <button type="submit" class="btn btn-default" name="up">UPDATE</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </form>
                    <?php 
    }
    }
    ?>
                </div>
                
<?php 
    include_once('common/fooder.php');
    ?>


    

                       
                         <!-- jquery vendor -->
    <script src="js/lib/jquery.min.js"></script>
    <script src="js/lib/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="js/lib/menubar/sidebar.js"></script>
    <script src="js/lib/preloader/pace.min.js"></script>
    <!-- sidebar -->

    <script src="js/lib/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <!-- bootstrap -->

    <script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="js/lib/calendar-2/pignose.init.js"></script>


    <script src="js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="js/lib/weather/weather-init.js"></script>
    <script src="js/lib/circle-progress/circle-progress.min.js"></script>
    <script src="js/lib/circle-progress/circle-progress-init.js"></script>
    <script src="js/lib/chartist/chartist.min.js"></script>
    <script src="js/lib/sparklinechart/jquery.sparkline.min.js"></script>
    <script src="js/lib/sparklinechart/sparkline.init.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="js/dashboard2.js"></script>
    <script src="http://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(document).ready( function () {
    $('#myTable').DataTable();
} );
    </script>
    
</body>
</html>
<?php
    if(isset($_POST['up'])){
        $hospitalname=$_POST['name'];
        $hospitallocation=$_POST['location'];
        $hospitalemail=$_POST['email'];
        $hospitalpassword=$_POST['password'];
        $update="UPDATE hospital SET hospitalname='$hospitalname',hospitallocation='$hospitallocation',hospitalemail='$hospitalemail',  hospitalpassword='$hospitalpassword' WHERE id='$id'";
            if( mysqli_query($conn, $update)){
                echo "row update ";
                ?>
                <script>
                    window.location.href='viewhospital.php';
                </script>
                    <?php

                }
                else{
                    echo "not updated";
                }

        }
        ?>


    }
?>


